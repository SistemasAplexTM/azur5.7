@extends('layouts.app')
@section('title', 'Inicio')
@section('breadcrumb')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>
            Inicio
        </h2>
    </div>
</div>
@endsection
@section('content')
<div class="row" id="homeIndex">
    <div class="col-lg-12">
        <div class="wrapper wrapper-content animated fadeInRight" style="padding-top: 0px;">
            <div class="row">
                bienvenido
            </div>
        </div>
    </div>
</div>
@endsection