﻿using System.Windows.Controls;

namespace wpf_generator.Views
{
    /// <summary>
    /// Interaction logic for GeneratorView.xaml
    /// </summary>
    public partial class GeneratorView : UserControl
    {
        public GeneratorView()
        {
            InitializeComponent();
        }
    }
}
