<!DOCTYPE html>
<html>
<head>
	<title><?php echo e($name_uds); ?></title>
</head>
<body>
	
	<table border="1" cellspacing="0" cellpadding="0">
		<thead>
			<tr>
				<th colspan="2"></th>
			</tr>
			<tr>
				<th colspan="2"></th>
				<th>CLIENTE: CAIP INDUSTRIAL LOS MANGOS</th>
			</tr>
			<tr>
				<th colspan="2"></th>
				<th>Nit: 890.318.793-8</th>
			</tr>
			<tr>
				<th colspan="2"></th>
				<th>PROYECTO CDI INSTITUCIONAL </th>
			</tr>
			<tr>
				<th colspan="2"></th>
				<th>NOMBRE DE LA UDS: <?php echo e($name_uds); ?></th>
			</tr>
			<tr>
				<th colspan="2"></th>
				<th>ENTREGA DE RACIONES -  <?php echo e($name_minuta); ?></th>
			</tr>
			<tr>
				<th colspan="2">CALLE 49 No.3GN - 42 BARRIO VIPASA</th>
				<th>DIAS DE ATENCION: </th>
			</tr>
			<tr>
				<th colspan="2">TELEFONO 410 2392</th>
				<th>FECHA DE ENTREGA : </th>
			</tr>

			<tr>
				<th colspan="2"></th>
			</tr>
			<tr>
				<th colspan="2"></th>
			</tr>
			<tr>
				<th><div style="border: solid 1px #000;">INGREDIENTES</div></th>
				<th>TOTAL EN LITROS KILOS O UNIDADES</th>
				<th>PEDIDO</th>
				<th>OBSERVACION</th>
			</tr>
		</thead>
		<tbody>
			<?php if(count($data) > 0): ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($dt->MENU); ?></td>
						<td>
							<?php $remanencia = 0; ?>
							<?php if(count($remanencias) > 0): ?>
								<?php $__currentLoopData = $remanencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $re): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($re->producto == $dt->MENU): ?>
										<?php $remanencia += $re->cantidad; ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
							<?php echo e((($dt->TOTAL_PEDIDO - $remanencia) < 0) ? 0 : ($dt->TOTAL_PEDIDO - $remanencia)); ?>

						</td>
						<td><?php echo e($dt->UNIDAD_MEDIDA); ?></td>
						<td><?php echo e(($remanencia > 0) ? 'Remanencia '.$remanencia : ''); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tbody>
		<tfoot>
			<tr><th></th></tr>
			<tr><th></th></tr>
			<tr><th>NOMBRE DE QUIEN RECIBE</th></tr>
			<tr><th>FIRMA</th></tr>
			<tr><th>C.C. No.</th></tr>
			<tr><th></th></tr>
			<tr><th></th></tr>
			<tr><th>NOMBRE : WILMER JULIAN CASTRO ORTIZ</th></tr>
			<tr><th>CEDULA: 1143.831.917 de Cali</th></tr>
			<tr><th>FIRMA:__________________________________</th></tr>
			<tr><th></th></tr>
		</tfoot>
	</table>
</body>
</html>