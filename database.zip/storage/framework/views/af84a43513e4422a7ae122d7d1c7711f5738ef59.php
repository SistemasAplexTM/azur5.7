<?php $__env->startSection('title', 'Inicio'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>
            Inicio
        </h2>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row" id="homeIndex">
    <div class="col-lg-12">
        <div class="wrapper wrapper-content animated fadeInRight" style="padding-top: 0px;">
            <div class="row">
                bienvenido
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>