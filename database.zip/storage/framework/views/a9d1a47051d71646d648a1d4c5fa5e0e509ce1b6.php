<!DOCTYPE html>
<html>
<head>
	<title>Minuta</title>
</head>
<body>
	
	<table border="1" cellspacing="0" cellpadding="0">
		<thead>
			<tr>
				<th>MENU</th>
				<?php if(count($uds) > 0): ?>
					<?php $__currentLoopData = $uds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<th><?php echo e($ud->name_uds); ?></th>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				<th>TOTAL PEDIDO</th>
				<th>UNIDAD MEDIDA</th>
			</tr>
		</thead>
		<tbody>
			<?php if(count($data) > 0): ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($dt->MENU); ?></td>
						<?php $arr = (array)$dt; ?>
						<?php $__currentLoopData = $uds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<td><?php echo e($arr[str_replace(' ', '_', $ud->name_uds)]); ?></td>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($dt->TOTAL_PEDIDO); ?></td>
						<td><?php echo e($dt->UNIDAD_MEDIDA); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tbody>
	</table>
</body>
</html>