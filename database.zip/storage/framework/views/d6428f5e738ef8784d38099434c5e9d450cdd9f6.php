<?php $__env->startSection('title', 'Minutas'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
</style>
    <div class="row" id="minuta">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5><?php echo e($minuta->name_minuta); ?><?php echo e($minuta->mes); ?></h5>
                </div>
                <div class="ibox-content">
                <!--***** contenido ******-->
                	<minuta-component :minuta="<?php echo e(json_encode($minuta)); ?>" :menus="<?php echo e(json_encode($menus)); ?>" :unidades="<?php echo e(json_encode($unidades)); ?>" :name_minuta="<?php echo e(json_encode($minuta->name_minuta . $minuta->mes)); ?>"></minuta-component>
                        
            </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/templates/minuta/minuta.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>