<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <span>
                        <img alt="image" class="img-circle" id="imgProfile" style="width: 150px;" src="<?php echo e(asset('storage/aplextm - Gmail.png')); ?>"/>
                    </span>
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <span class="clear">
                            <span class="block m-t-xs">
                                <strong class="font-bold">
                                    <?php echo e(Auth::user()->name); ?>

                                </strong>
                            </span>
                            <span class="text-muted text-xs block">
                                Bienvenido
                                <b class="caret">
                                </b>
                            </span>
                        </span>
                    </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                        <li>
                            <a href="<?php echo e(route('home')); ?>">
                                <i class="fa fa-home">
                                </i>
                                Inicio
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-user">
                                </i>
                                Perfil
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="logo-element">
                    4plbox
                </div>
            </li>
            <!--id='firstMenu'-->
            <li class="active" id="firstMenu">
                <a href="" style="background-color: #BA55D3; color: white;">
                    <i class="fa fa-clipboard">
                    </i>
                    <span class="nav-label">
                        Documentos
                    </span>
                    <span class="fa arrow">
                    </span>
                </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('minuta.index')); ?>">
                            <spam class="fa fa-file-text">
                            </spam>
                            Minutas
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menus.index')): ?>
                        <li>
                            <a href="<?php echo e(route('menus.index')); ?>">
                                <spam class="fa fa-list">
                                </spam>
                                Menus
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
            <li class="active" id="firstMenu">
                <a href="" style="background-color:#f17720; color: white;">
                    <i class="fa fa-user-circle">
                    </i>
                    <span class="nav-label">
                        Clientes
                    </span>
                    <span class="fa arrow">
                    </span>
                </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('clientes.index')); ?>">
                            <spam class="fa fa-user-circle">
                            </spam>
                            Clientes
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('unidadServicio.index')); ?>">
                            <spam class="fa fa-home">
                            </spam>
                            Unidades de servicio
                        </a>
                    </li>
                </ul>
            </li>
            <li class="active" id="firstMenu">
                <a href="" style="background-color: #1793dc; color: white;">
                    <i class="fa fa-file-text">
                    </i>
                    <span class="nav-label">
                        Informes
                    </span>
                    <span class="fa arrow">
                    </span>
                </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="#">
                            <spam class="fa fa-file-text">
                            </spam>
                            Inventario
                        </a>
                    </li>
                </ul>
            </li>
            <li class="active" id="firstMenu">
                <a href="" style="background-color: #017767; color: white;">
                    <i class="fa fa-cogs">
                    </i>
                    <span class="nav-label">
                        Administracion
                    </span>
                    <span class="fa arrow">
                    </span>
                </a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo e(route('product.index')); ?>">
                            <spam class="fa fa-cubes">
                            </spam>
                            Productos
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('administracion/unidad_de_medida')); ?>">
                            <spam class="fa fa-balance-scale">
                            </spam>
                            Unidad de medida
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('administracion/grupo_edad')); ?>">
                            <spam class="fa fa-child">
                            </spam>
                            Grupo de edades
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('administracion/tipo_unidad_servicio')); ?>">
                            <spam class="fa fa-home">
                            </spam>
                            Tipo US
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('administracion/tipo_producto')); ?>">
                            <spam class="fa fa-cubes">
                            </spam>
                            Tipo producto
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo e(route('logActivity.index')); ?>">
                            <spam class="fa fa-history">
                            </spam>
                            Logs
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    
</nav>
